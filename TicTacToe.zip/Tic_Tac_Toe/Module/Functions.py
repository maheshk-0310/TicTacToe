from os import system,name
def clear():
    #clears the screen
    if name=='nt':
        _ = system('cls')

def validate_draw():
    #Checks if the game is draw
    global myboard
    draw=False
    for k,v in myboard.items():
        for i in v:
            if(i in range(0,10)):
                return draw
    draw=True
    return draw

def validate_win(value):
    #checks if either of the player won
    global myboard
    if((myboard[1][0]==value and myboard[1][1]==value and myboard[1][2]==value) or
       (myboard[2][0]==value and myboard[2][1]==value and myboard[2][2]==value) or
       (myboard[3][0]==value and myboard[3][1]==value and myboard[3][2]==value) or
       (myboard[1][0]==value and myboard[2][0]==value and myboard[3][0]==value) or
       (myboard[1][1]==value and myboard[2][1]==value and myboard[3][1]==value) or
       (myboard[1][2]==value and myboard[2][2]==value and myboard[3][2]==value) or
       (myboard[1][0]==value and myboard[2][1]==value and myboard[3][2]==value) or
       (myboard[1][2]==value and myboard[2][1]==value and myboard[3][0]==value)):
        return True
    else:
        return False

def display_board():
    #displays the board
    global myboard
    print(f'\n\n|  {myboard[1][0]}  |  {myboard[1][1]}  |  {myboard[1][2]}  |\n|  {myboard[2][0]}  |  {myboard[2][1]}  |  {myboard[2][2]}  |\n|  {myboard[3][0]}  |  {myboard[3][1]}  |  {myboard[3][2]}  |\n\n')

def ploting(index,value):
    #plots the given value 'X' or 'O'
    global myboard
    for k,v in myboard.items():
        for i in range(0,len(v)):
            if(v[i]==index):
                myboard[k][i]=value
                return True
    return False

def gameplay(player):
    #Game logic
    win=False
    while not win:
        #win=False
        mark=''
        if(player.lower()=='p1'):
            mark='X'
        else:
            mark='O'
        print(f'\n\n{player}\'s turn!')
        display_board()
        valid_pos=True
        while valid_pos:
            plot=input(f'\n\nEnter position where you want to plot {mark} :')
            if plot.isdigit():
                if(int(plot) in range(1,10)):
                    clear()
                    valid_pos=False
                else:
                    clear()
                    display_board()
                    print("Invalid input. Please enter a valid position! (1-9)")
            else:
                clear()
                display_board()
                print("Invalid input. Please enter a valid position! (1-9)")
        if ploting(int(plot),mark):
            win=validate_win(mark)
            if win:
                clear()
                print(f'\n\n{player} WON!!')
                win=False
                display_board()
                break
            else:
                if validate_draw():
                    clear()
                    print("Draw!!\n\n")
                    display_board()
                    win=False
                    break
                if player=='p1':
                    player='p2'
                else:
                    player='p1'
        else:
            clear()
            print("\n\nInvalid input. The position is already filled.")
            player='p1'

def start_game():
    global myboard
    choice='Y'
    while choice.upper()=='Y':
        myboard={1:[1,2,3],2:[4,5,6],3:[7,8,9]}
        clear()
        print("\n\n********** Welcome to Tic Tac Toe!!!********** ")
        valid_player=True
        while valid_player:
            player=input("\n\nWho's going first ? (P1/P2) : ")
            if(player.lower() in ['p1','p2']):
                clear()
                valid_player=False
            else:
                clear()
                display_board()
                print("Invalid input. Please enter a player as p1/p2!")
        gameplay(player)
        valid_play_again=True
        while valid_play_again:
            choice=input("Do you want to play again? (Y/N): ")
            if choice.lower() in ['y','n']:
                valid_play_again=False
            else:
                clear()
                print("Invalid input. Please enter Y or N. ")
    clear()
    print("\n\nAlright then! Thank you for playing!")