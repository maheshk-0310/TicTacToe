from Module import Functions

#Global board
myboard={1:[1,2,3],2:[4,5,6],3:[7,8,9]}

Functions.start_game()
end=input("\n\nPress Enter key to exit!")